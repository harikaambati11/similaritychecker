from django.contrib import admin
from .models import File1,File2,Result

admin.site.register(File1)
admin.site.register(File2)
admin.site.register(Result)

# Register your models here.
